# TODO list

* continue to help files
* fix hard-coding parts
* allow to run original model in Madjar et al. (2021)
* add more functions for the visualization of results

# BayesSurv 0.0-3

* Added thinning parameter

# BayesSurv 0.0-2

* Improved help files

# BayesSurv 0.0-1

* First GitHub commit version
